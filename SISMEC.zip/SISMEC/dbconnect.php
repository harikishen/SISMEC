<?php
$servername = "localhost";
$username = "root";
$password = "turbodrive111";
$dbname = "harikishen";

?>
