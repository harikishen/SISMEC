<?php
echo"No Details Of Specified Student";
?>
