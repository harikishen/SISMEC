<html>
<head><title>SISMEC</title>
<link rel="stylesheet" href="edit.css" type="text/css">
</head>
<body>

	<div id="wrapper">
		<div id="box">
			<form action="view.php" method="post">
				Admission No.<input type="text" size="17" name="sroll" ><br><br>
			<!--	Name<input type="text" size="20" name="sname"><br>-->
				<input type ="submit" id="sub" value="&check;">
			</form>
			
		</div>	
		<center><a href="../index.html">Home</a></center>
	</div>

</body>
<html>
